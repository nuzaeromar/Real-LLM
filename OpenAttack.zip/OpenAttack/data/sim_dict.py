"""
:type: dict
:Size: 276.083KB

Dictionary file for ChineseSIMChar substitute.
"""
NAME = "AttackAssist.SIM"
DOWNLOAD = "/TAADToolbox/sim_dict.pkl"
# LOAD = pickle