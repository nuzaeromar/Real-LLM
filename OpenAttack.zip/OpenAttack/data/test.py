NAME = "test"
DOWNLOAD = "/TAADToolbox/test.pkl"
