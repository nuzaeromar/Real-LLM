"""
:type: dict
:Size: 1.752MB

Dictionary file for delemmatizer.
"""
NAME = "TProcess.NLTKWordNetDelemma"
DOWNLOAD = "/TAADToolbox/word_delemma.pkl"
# LOAD = pickle
