from ..exception import AttackException


class InvokeLimitExceeded(AttackException):
    pass
