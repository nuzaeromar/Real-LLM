from ..exception import AttackException


class DataConfigErrorException(AttackException):
    pass
