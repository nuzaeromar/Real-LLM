from .base import CharSubstitute
from .chinese_fyh_char import ChineseFYHCharSubstitute
from .chinese_sim_char import ChineseSimCharSubstitute
from .english_dces import DCESSubstitute
from .english_eces import ECESSubstitute