from .base import AttackGoal
from .classifier_goal import ClassifierGoal